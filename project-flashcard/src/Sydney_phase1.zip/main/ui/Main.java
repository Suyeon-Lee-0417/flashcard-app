package ui;


public class Main {
    public static void main(String[] args) throws Exception {
        System.out.println("Welcome to my project!\n");
        FlashCardApp flashcardApp = new FlashCardApp();
        flashcardApp.run();
    }
}

// FCardCollection collection = new FCardCollection();
// Flashcard card = new Flashcard("Question", "Answer");
// collection.add(card);
// collection.add(new Flashcard("Question", "Answer"));
// collection.viewCardList();
// collection.edit(1);
// collection.delete(1); // index
// collection.viewDetail(1);

// collection.startReview();
// collection.viewListLearned();
// collection.viewCardList();

// collection.markAsLearned(1); // update learning status of a card individually
// collection.markAsStillLearning(2);

// collection.numberStillInLearning();
// collection.numberLearned();

