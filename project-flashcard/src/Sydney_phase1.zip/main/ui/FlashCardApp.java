package ui;

import model.FCardCollection;
import model.Flashcard;
import java.util.Scanner;
import java.util.ArrayList;

public class FlashCardApp {

    private FCardCollection cardList;
    private Scanner scanner;
    private boolean keepGoing;
    private int currentIndex;
    private int numOfCards;
    private boolean backToMain;

    /*
     * constructor
     * EFFECTS: create an empty list of Flashcards
     */
    public FlashCardApp() {
        cardList = new FCardCollection();
        scanner = new Scanner(System.in);
        keepGoing = true;
        currentIndex = 0;
        numOfCards = 0;
        backToMain = false;
    }

    /*
     * EFFECTS: launch the app; 
     * starting message; display the starting menu.
     */
    public void run(){
        System.out.println("Starting the FlashCard app...");
        while(keepGoing){
            mainMenu();
            processMainMenu();
            
            if(backToMain){
                backToMain = false;
            }
        }
        System.out.println("Exit the FlashCard app...\n");

    }

    /*
     * EFFECTS: 1) display Starting menu options 2) get user selection 
     * 3) process selected option 
     * 
     */
    public void processMainMenu(){
        char inputChar = getUserInput();
        boolean invalidInput = false;

        do {
            switch(inputChar){
                case '1':
                    invalidInput = false;
                    addNewCard();
                    break;
                case '2':
                    invalidInput = false;
                    displayAllCards();
                    if(backToMain){
                        return;
                    }
                    break;
                case '3':
                    review();
                    invalidInput = false;
                    if(backToMain){
                        return;
                    }
                    break;
                case '4':
                    System.out.println("\n----<Quitting the app>----\n");
                    System.out.println("        Bye Bye!        ");
                    keepGoing = false;
                    break;
                default:
                    System.out.println("\nInvalid input!\n");
                    invalidInput = true;
                    inputChar = getUserInput();
            }
        } while(invalidInput && keepGoing);
    }

     /*
     * REQUIRES:
     * EFFECTS: prints out all menu options
     */
    public void mainMenu(){
        printLine();
        System.out.println("Main menu: \n"
            + "1: create a new vocabulary card\n"
            + "2: show every vocabularies\n"
            + "3: start vocab review for still in learning\n"
            + "4: quit"
        );
    }


    /*
     * 
     * REQUIRES: valid prompt and description input from user
     * MODIFIES: this
     * EFFECTS: get term and description from user;
     * create a new Flashcard and add it to cardList 
     */
    public void addNewCard(){
        System.out.println("\n----<Create a new FlashCard>----\n");

        String term = "";
        String description = "";
        while(term.length() <= 0 || description.length() <= 0){
            System.out.println("Type the term for a new flashcard : ");
            term = scanner.nextLine();
            System.out.println("\nType the description(answer) for a new flashcard : ");
            description = scanner.nextLine();
            if(term.length() <= 0 || description.length() <= 0){
                System.out.println("Invalid input. Please type it again");
            }
        }
        numOfCards++;
        System.out.println("\nNew flashcard is created!");
        cardList.addNewCard(new Flashcard(term, description));
    }

    /*
     * EFFECTS: Prints out every flashcards in the cardList with options for each card;
     * Warn the user if the cardList is empty.
     */
    public void displayAllCards(){
        /*
         * TODO : edit했을때 App필드인 cardList에 변경사항이 유지되는지 확인
         */

        char inputChar;
        System.out.println("\n----<Show every flashcards>----\n");

        // print through the cardList
        while(currentIndex >= 0 && currentIndex < numOfCards && !backToMain){
            int count = currentIndex + 1;
            Flashcard card = cardList.getFlashCard(currentIndex);
            System.out.println("No. " + count + "\n");
            System.out.println("Term: " + card.getTerm() + "\n");
            System.out.println("Description: " + card.getDescription() + "\n");
            System.out.println("Learned? : " + card.getLearningStatus());
            printLine();

            menuForDisplayAll();
            inputChar = getUserInput();
            processMenuInDisplayAll(inputChar);
        }
        if(currentIndex < 0){
            System.out.println("This is the first card! \n"
            + "Back to main menu");
        }
        if(currentIndex >= numOfCards){
            System.out.println("This is the last card! \n"
            + "Back to main menu");
        }

        currentIndex = 0;
    }

    /*
     * EFFECTS: prints out the options for each Flashcard.
     */
    public void menuForDisplayAll(){
        System.out.println("a: edit card\n"
        + "b: next card\n"
        + "c: previous card\n"
        + "d: delete this card\n"
        + "e: mark as still learning\n"
        + "f: back to main menu"
        );
    }
    
    /*
     * helper method for displayAll()
     * 
     * EFFECTS: logic process for user's choice of while vewing every cards.
     * Process the choice.
     */
    public void processMenuInDisplayAll(char userInput){
        boolean invalidInput = false;
        
        do {
            switch(userInput) {
                case 'a':
                    // TODO: method for editing card
                    editDescription();
                    break;
                case 'b':
                    // TODO: next card
                    currentIndex++;
                    return;
                case'c':
                    // TODO: previous card
                    currentIndex--;
                    return;
                case'd':
                    // TODO: delete this card
                    deleteCard();
                    return;
                case'e':
                    // TODO: delete this card
                    if(cardList.getFlashCard(currentIndex).getLearningStatus()){
                        System.out.println("Status updated!");
                    } else {
                        System.out.println("Already 'still in Learning' !");
                    }
                    printLine();
                    return;
                case'f':
                    // TODO: back to main menu
                    backToMain = true;
                    return;
                default:
                    System.out.println("Invalid input\n");
                    userInput = getUserInput();
                    invalidInput = true;
            }
        } while(invalidInput);
    }

    /*
     * Helper for processMenuInDisplayAll()
     * EFFECTS: get new description from user and set it as a description of the current card.
     * 
     */
    public void editDescription(){
        //ask user
        //set it as new description
        boolean isValid = false;
        String newDescription = "";
        System.out.println("Type new definition: ");

        while(!isValid){
            newDescription = scanner.nextLine();
            if(newDescription.length() >= 0){
                isValid = true;
            }else {
                System.out.println("invalid input.\nType new definition: ");
            }
        }
        cardList.getFlashCard(currentIndex).editDescription(newDescription);
        System.out.println("\nDescription edited!");
    }

    /*
     * helper for processMenuInDisplayAll()
     * 
     * MODIFIES: this (numOfCards, currentIndex)
     * EFFECTS: delete the current flashcard and notify user. 
     * Decrement numOfCards
     */
    public void deleteCard(){
        cardList.deleteCard(currentIndex);
        numOfCards = cardList.getNumFCards();
        System.out.println("\nDeleted the card");

    }

    /*
     * 
     * EFFECTS: starts review session for cards with stillInLearning status;
     * displays the options for each reviewing card; 
     * process the option selected by user;
     * prints warning sign if there is no cards to review
     */
    public void review(){
        // start prompt
        // show only the term of card
        // show menuForReview

        //TODO : if there's no card to review, notify user

        System.out.println("----<Review Session starts>----");
        ArrayList<Flashcard> reviewList = cardList.gatherFlashcardsToReview();
        while(currentIndex >= 0 && currentIndex < reviewList.size() && !backToMain){
            String term = reviewList.get(currentIndex).getTerm();
            System.out.println(term + "\n");
            menuForReview();
            char userInput = getUserInput();
            processMenuInReview(userInput);
        }
        if(currentIndex < 0){
            System.out.println("This is the first card! \n"
            + "Back to main menu");
        }
        if(currentIndex >= reviewList.size()){
            System.out.println("This is the last card! \n"
            + "Back to main menu");
        }
        currentIndex = 0;
    }

    /* 
     * helper for review
     * 
     * EFFECTS: displays the options for each card during the review session 
     * for user.
     */
    public void menuForReview(){
        System.out.println("a: check my answer\n"
        + "b: next card\n"
        + "c: previous card\n"
        + "d: back to main\n"
        );
    }

    /*
     * EFFECTS: logic process for user's choice of option. Process the option.
     */
    public void processMenuInReview(char userInput){

        boolean invalidInput = false;
        do {
            switch(userInput) {
                case 'a':
                    checkUserAnswer();
                    currentIndex++;
                    break;
                case 'b':
                    currentIndex++;
                    return; 
                case'c':
                    currentIndex--;
                    return;
                case 'd':
                    backToMain = true;
                    return;
                default:
                    System.out.println("Invalid input\n");
                    userInput = getUserInput();
                    invalidInput = true;
            }
        } while(invalidInput);
    }

    /*
     * REQUIRES: user answer length > 0
     * EFFECTS: get user answer; Check if the user answer is correct; 
     * get user answer again if user select 'try again'
     * displays the options for each cases- correct or incorrect and process selection for options.
     */
    public void checkUserAnswer(){
        printLine();
        boolean tryAgain = false;
        Flashcard currentCard = cardList.getFlashCard(currentIndex);
        
        do{
            System.out.println("Type your answer for " + currentCard.getTerm() + " : ");
            String userAnswer = scanner.nextLine();
            if(currentCard.getDescription().equals(userAnswer)){
                userAnswerCorrect();
                tryAgain = false;
            }else {
                userAnswerIncorrect(); //menu
                tryAgain = processIncorrectAnsMenu(); // either try again or show answer depends on the userChoice
            }
        } while(tryAgain);
    }

    /*
     * helper for checkUserAnswer()
     * EFFECTS: 
     * either try again or show answer depends on the userChoice
     */
    public boolean processIncorrectAnsMenu(){
        boolean invalidInput = false;
        do{
            char userInput = getUserInput();
            switch (userInput) {
                case 'a':
                    invalidInput = false;
                    break;
                case 'b':
                    showAnswer();
                    return false;
                default:
                    System.out.println("invalid input!\nTry again");
                    invalidInput = true;
            }
        } while(invalidInput);
        
        // TODO : is there a better way than this?
        return true;
    }
    /*
    * helper method for checkUserAnswer()
    * case: user answer is Incorrect
    * EFFECTS: displays the options for incorrect answer;
    * option a) try again
    * option b) see answer
    */
    public void userAnswerIncorrect(){
        printLine();
        System.out.println("Wrong answer\n");
        System.out.println("a: Try again");
        System.out.println("b: See answer");
        printLine();
        
    }
        
        /*
         * case: user answer is Incorrect
         * helper method for userAnswerIncorrect()
         * REQUIRES: card != null
         * EFFECTS: show the answer for the current flashcard
         */
        public void showAnswer(){
            // Stub
            printLine();
            System.out.println("\nThe answer for " + cardList.getFlashCard(currentIndex).getTerm() + " is :");
            System.out.println("\"" + cardList.getFlashCard(currentIndex).getDescription() + "\"");
            printLine();
        }

    /*
     * helper method for checkUserAnswer()
     * case: user answer is correct
     * MODIRIES: this
     * EFFECTS: notify user's answer is correct; mark current card as "Learned".
     */
    public void userAnswerCorrect(){
        printLine();
        System.out.println("Correct answer!\n");
        cardList.markThisCardAsLearned(currentIndex);
        printLine();
    }

    public void printLine(){
        System.out.println("");
        System.out.println("-------------------");
        System.out.println("");
    }


    /*
     * helper for displayAll() and review()
     * EFFECTS: Notify user there's no cards to view;
     * move back to previous menu
     */
    public void endOfTheList(){
        // Stub
    }

    

    /*
     * case: user answer is correct
     * helper method for userAnswerCorrect().
     * EFFECTS: mark the status of current card as Learned;
     */
    public void markAsLearned(){
        // Stub 
    }


    /*
     * EFFECTS: helper method; Get input from user
     */
    public char getUserInput(){
        String inputString = "";
        System.out.println("\nType the option chosen");
        inputString = scanner.nextLine();
        while(inputString.length() <= 0){
           System.out.println("Please type your option again");
            inputString = scanner.nextLine();
        }
        char inputChar = inputString.charAt(0);
        System.out.println("");
        return inputChar;
    }
   
}