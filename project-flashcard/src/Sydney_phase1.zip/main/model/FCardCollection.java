package model;

import java.util.ArrayList;

/**
 * FCardCollection class collects Flashcard objects.
 * Generates review session for flashcards 'still in learning'
 * after checking each flashcard's learning status
 * It can delete/edit/add flashcard in the collection
 * 
 * @version phase 1
 * @author Sydney Lee
 */
public class FCardCollection {
    private int stillLearning;
    private ArrayList<Flashcard> cardList;

    /*
     * EFFECTS: creates ArrayList of Flashcard with length 0;
     * set numberOfLearned to 0;
     * set stillLearning to 0.
     */
    public FCardCollection() {
        cardList = new ArrayList<>();
        stillLearning = 0;
    }

    /*
     * REQUIRES: newCard != null
     * MODIFIES: this
     * EFFECTS: add a new Flashcard into cardList;
     * increase stillLearning and numCards by 1.
     * 
     */
    public void addNewCard(Flashcard newCard) {
        cardList.add(newCard);
        stillLearning++;
    }

    /*
     * REQUIRES: cardList should have at least one Flashcard; 
     * target card's index should be valid.
     * MODIFIES: this
     * EFFECTS: delete a target Flashcard from cardList;
     * decrease stillInLearning by 1 if the target Flashcard is
     * not Learned yet.
     */
    public void deleteCard(int index) {
        if (cardList.size() > 0 && index <= cardList.size() - 1) { 
            if (!cardList.get(index).getLearningStatus()) {
                stillLearning--;
            }
            cardList.remove(index);
        }
        
    }

    // /*
    // * REQUIRES: cardList should have at least one Flashcard;
    // * (cardList length > 0)
    // * EFFECTS: return the number of Flashcards already Learned in the cardList;
    // * returns the .
    // */
    // public int getNumberLearned() {
    // // Stub
    // return learned;
    // }

    /*
     * EFFECTS: returns the number of Flashcards Still in Learning in the cardList;
     * returns stillLearning.
     */
    public int getNumStillLearning() {
        return stillLearning;
    }

    /*
     * REQUIRES:cardList should have at least one Flashcard;
     * (cardList length > 0)
     * EFFECTS: checks Flashcards in the cardlist and gather Flashcards
     * that are still in learning; Return the list of UnLearned Flashcards
     */
    public ArrayList<Flashcard> gatherFlashcardsToReview() {
        ArrayList<Flashcard> cardsToReview = new ArrayList<>();
        for (Flashcard card : cardList) {
            if (!card.getLearningStatus()) {
                cardsToReview.add(new Flashcard(card));
                // @TODO: is deep copy needed?
            }
        }
        return cardsToReview;
    }

    /*
     * REQUIRES: cardList should have at least one Flashcard;
     * (cardList length > 0)
     * EFFECTS: shows the entire list of Flashcard.
     */
    public ArrayList<Flashcard> showEveryFlashcards() {
        ArrayList<Flashcard> listToShow = new ArrayList<>();
        for (Flashcard card : cardList) {
            listToShow.add(new Flashcard(card));
        }
        return listToShow;
    }

    /*
     * EFFECTS: returns the number of Flashcards in the cardList.
     */
    public int getNumFCards() {
        return cardList.size();
    }

    public void markThisCardAsLearned(int cardNumber) {
        cardList.get(cardNumber).markAsLearned();
        stillLearning--;
    }

    public void markThisCardStillLearning(int cardNumber) {
        cardList.get(cardNumber).markAsStillLearning();
        stillLearning++;
    }

    public Flashcard getFlashCard(int index){
        return cardList.get(index);
    }


}
