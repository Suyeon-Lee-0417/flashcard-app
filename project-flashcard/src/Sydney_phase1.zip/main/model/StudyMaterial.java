// package model;

// /**
// * superclass of FCardCollection and FlashCardVocab.
// *
// */
// public abstract class StudyMaterial {
// String concept = "";
// String definition = "";

// // REQUIRE: concept.length() > 0, definition.length() > 0
// //
// public StudyMaterial(String concept, String definition) {
// // stub
// }

// public abstract void addMaterial(Flashcard card){
// return card;
// }

// public abstract void removeMaterial(){
// //stub
// }

// public abstract List<StudyMaterial> getMaterials(){
// //stub
// return new List<StudyMaterial>;
// }

// public abstract void displayDetails(){
// //stub
// }

// }